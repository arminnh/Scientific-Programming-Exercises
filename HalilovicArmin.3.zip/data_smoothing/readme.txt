Compile and run the program from the build/ directory with:
    cmake ..
    make
   chmod +x ./data_smoothing.sh
    ./data_smoothing.sh

Ouput will be generated in the output/ and images/ folders.
The program needs "graph" from the plotutils package to create graphs, so make sure that it is installed.
More information can be found in report.pdf