Compile and run the program from the build/ directory with:
    cmake ..
    chmod +x ./createImages.sh
    make
    ./data_fitting

The program needs "graph" from the plotutils package to create graphs, so make sure that it is installed.
More information can be found in report.pdf