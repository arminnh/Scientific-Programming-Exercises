function [ y ] = f(x)
    y = 1 + chebyshevT(6, x);
end
