Compile and run the program from the build/ directory with:
    cmake ..
    make
    chmod +x ./createImages.sh
    ./data_fitting_smoothing_and_fn_approx.bin