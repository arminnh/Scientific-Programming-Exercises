Compile and run the program from the build/ directory with:
    cmake ..
    make
    ./sys_lineq