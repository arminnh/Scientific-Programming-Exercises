Compile and run the program from the build/ directory with:
    cmake ..
    make
    ./sys_lineq

Output will be written to output.txt; more info about the output can be found in the report
