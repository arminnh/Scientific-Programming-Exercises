Compile and run the program from the build/ directory with:
    cmake ..
    make
    ./numerical_integration.bin

Ouput will be generated in the console.
More information can be found in report.pdf

