Compile and run the program from the build/ directory with:
    cmake ..
    make
    chmod +x ./function_approximation.sh
    ./function_approximation.bin

Ouput will be generated in the console and in the images/ folder.
The program needs "graph" from the plotutils package to create graphs, so make sure that it is installed.
More information can be found in report.pdf
